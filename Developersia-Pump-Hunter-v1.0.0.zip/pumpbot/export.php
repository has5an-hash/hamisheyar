<?php
declare(strict_types=1);
require_once __DIR__ . '/app/common.php';
if (!is_installed()) redirect('install.php'); require_login();
$state=json_read('state.json',[]);
header('Content-Type: text/csv; charset=UTF-8'); header('Content-Disposition: attachment; filename="pump-hunter-trades.csv"');
echo "\xEF\xBB\xBF";
$out=fopen('php://output','w');
fputcsv($out,['نوع','تاریخ','نماد','نام','Mint','مبلغ USDT','مبلغ تومان','نرخ تومان/USDT','مقدار ناخالص USDT','قیمت بازار','قیمت اجرا','کارمزد','هزینه شبکه','سود/زیان USDT','بازده درصد','علت','دلایل سیگنال']);
foreach (($state['trades'] ?? []) as $t) fputcsv($out,[$t['type']??'', $t['at']??'', $t['symbol']??'', $t['name']??'', $t['mint']??'', $t['amount_usdt']??'', $t['amount_toman']??'', $t['fx_rate_toman_per_usdt']??'', $t['usdt_gross']??'', $t['market_price_usd']??'', $t['execution_price_usd']??'', $t['fee_usdt']??'', $t['network_fee_usdt']??'', $t['pnl_usdt']??'', $t['roi_pct']??'', $t['reason']??'', isset($t['signal_reasons']) ? implode(' | ',$t['signal_reasons']) : (isset($t['entry_reasons']) ? implode(' | ',$t['entry_reasons']) : '')]);
fclose($out); exit;
