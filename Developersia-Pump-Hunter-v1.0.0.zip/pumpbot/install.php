<?php
declare(strict_types=1);
require_once __DIR__ . '/app/common.php';
date_default_timezone_set('Asia/Tehran');
if (is_installed()) redirect('index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $password=(string)($_POST['password'] ?? '');
    $confirm=(string)($_POST['confirm_password'] ?? '');
    if (strlen($password)<12) $error='رمز عبور باید حداقل ۱۲ کاراکتر باشد.';
    elseif ($password !== $confirm) $error='تکرار رمز عبور مطابقت ندارد.';
    else {
        $config=[
            'admin_password_hash'=>password_hash($password,PASSWORD_DEFAULT),
            'initial_toman'=>max(100000,(float)($_POST['initial_toman'] ?? 3000000)),
            'usdt_conversion_fee_pct'=>0.20,
            'trade_fee_pct'=>0.30,
            'network_fee_usdt'=>0.0005,
            'max_open_positions'=>4,
            'max_daily_loss_pct'=>5.0,
            'trading_enabled'=>true,
            'jupiter_api_key'=>trim((string)($_POST['jupiter_api_key'] ?? '')),
            'telegram_bot_token'=>trim((string)($_POST['telegram_bot_token'] ?? '')),
            'telegram_chat_id'=>trim((string)($_POST['telegram_chat_id'] ?? '')),
            'created_at'=>date('c'),
            'app_version'=>'1.0.0'
        ];
        if (!save_config($config)) $error='امکان ذخیره تنظیمات وجود ندارد. دسترسی نوشتن پوشه storage را بررسی کنید.';
        else {
            @file_put_contents(store_path('installed.lock'), date('c'));
            @chmod(store_path('installed.lock'),0640);
            json_write('state.json', ['initialized'=>false,'positions'=>[],'trades'=>[],'decisions'=>[],'closed_tokens'=>[],'cash_usdt'=>0.0]);
            json_write('daily.json', []);
            log_event('INFO','نصب اولیه کامل شد');
            redirect('login.php?installed=1');
        }
    }
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب Pump Hunter</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-bg"><div class="auth-card wide"><div class="brand auth-brand"><div class="brand-mark">D</div><div><strong>Developersia Pump Hunter</strong><small>نصب و راه‌اندازی</small></div></div><h1>راه‌اندازی ربات</h1><p class="muted">حساب آزمایشی با سرمایه اولیه ۳ میلیون تومان ایجاد می‌شود. نصب فقط یک‌بار انجام می‌شود.</p>
<?php if ($error): ?><div class="notice danger"><?= h($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><label>سرمایه اولیه (تومان)<input type="number" name="initial_toman" value="3000000" min="100000" step="1000" required></label><div class="form-grid"><label>رمز عبور پنل (حداقل ۱۲ کاراکتر)<input type="password" name="password" minlength="12" autocomplete="new-password" required></label><label>تکرار رمز عبور<input type="password" name="confirm_password" minlength="12" autocomplete="new-password" required></label></div><details><summary>تنظیمات اختیاری اتصال‌ها</summary><label>Jupiter API Key (اختیاری)<input type="password" name="jupiter_api_key" autocomplete="off"><small>بدون کلید هم نسخه رایگان با محدودیت درخواست پایین کار می‌کند.</small></label><div class="form-grid"><label>Telegram Bot Token (اختیاری)<input type="password" name="telegram_bot_token" autocomplete="off"></label><label>Telegram Chat ID (اختیاری)<input type="text" name="telegram_chat_id"></label></div><small>برای گزارش تلگرام باید هر دو مقدار وارد شوند.</small></details><button class="btn primary full" type="submit">نصب و ساخت حساب آزمایشی</button></form><div class="footer-note">این برنامه فقط داده عمومی بازار را می‌خواند و معامله واقعی انجام نمی‌دهد.</div></div></body></html>
