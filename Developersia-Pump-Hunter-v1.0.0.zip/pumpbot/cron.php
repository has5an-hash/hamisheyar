<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/app/engine.php';
date_default_timezone_set('Asia/Tehran');
$result=run_paper_engine();
echo '['.date('Y-m-d H:i:s').'] '.($result['ok']?'OK':'NOTICE').' - '.($result['message'] ?? '').PHP_EOL;
if (!$result['ok'] && strpos((string)($result['message'] ?? ''),'اجرای قبلی')===false) exit(1);
