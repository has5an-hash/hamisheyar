<?php
declare(strict_types=1);
require_once __DIR__ . '/app/common.php';
date_default_timezone_set('Asia/Tehran');
if (!is_installed()) redirect('install.php');
app_session_start();
if (!empty($_SESSION['pumpbot_logged_in'])) redirect('index.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $attempts=json_read('login_attempts.json', ['count'=>0,'since'=>time()]);
    if (time()-(int)$attempts['since']>900) $attempts=['count'=>0,'since'=>time()];
    if ((int)$attempts['count']>=8) $error='تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقه بعد دوباره امتحان کنید.';
    else {
        $cfg=app_config();
        if (password_verify((string)($_POST['password'] ?? ''),(string)$cfg['admin_password_hash'])) {
            @unlink(store_path('login_attempts.json'));
            session_regenerate_id(true); $_SESSION['pumpbot_logged_in']=true; $_SESSION['csrf']=bin2hex(random_bytes(24));
            redirect('index.php');
        }
        $attempts['count']=(int)$attempts['count']+1; json_write('login_attempts.json',$attempts); $error='رمز عبور اشتباه است.';
    }
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ورود به Pump Hunter</title><link rel="stylesheet" href="assets/style.css"></head><body class="auth-bg"><div class="auth-card"><div class="brand auth-brand"><div class="brand-mark">D</div><div><strong>Developersia Pump Hunter</strong><small>ورود مدیر</small></div></div><h1>ورود به پنل</h1><?php if(isset($_GET['installed'])): ?><div class="notice success">نصب با موفقیت انجام شد. برای شروع، کران‌جاب را هم فعال کنید.</div><?php endif; ?><?php if($error): ?><div class="notice danger"><?= h($error) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><label>رمز عبور<input type="password" name="password" autocomplete="current-password" required autofocus></label><button class="btn primary full" type="submit">ورود</button></form></div></body></html>
