<?php
/** Paper-trading engine. No wallet, private key, signing or live-swap code exists here. */
declare(strict_types=1);
require_once __DIR__ . '/common.php';

define('USDC_MINT', 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v');

function http_json(string $url, array $headers = [], int $timeout = 12): array {
    $r = api_get($url, $headers, $timeout);
    $host = (string)(parse_url($url, PHP_URL_HOST) ?: 'unknown');
    $health = json_read('api_health.json', []);
    $health[$host] = ['at'=>date('c'),'ok'=>(bool)$r['ok'],'status'=>(int)($r['status'] ?? 0),'error'=>$r['ok'] ? '' : (string)($r['error'] ?? 'API error')];
    json_write('api_health.json', $health);
    if (!$r['ok']) return $r;
    return ['ok'=>true, 'data'=>$r['data'], 'status'=>$r['status']];
}
function get_usdt_irt_rate(): array {
    $r = http_json('https://apiv2.nobitex.ir/v3/orderbook/USDTIRT', [], 6);
    if (!$r['ok']) return $r;
    $data = $r['data'];
    $ask = isset($data['asks'][0][0]) ? (float)$data['asks'][0][0] : 0.0;
    $bid = isset($data['bids'][0][0]) ? (float)$data['bids'][0][0] : 0.0;
    if (($data['status'] ?? '') !== 'ok' || $ask <= 0 || $bid <= 0) return ['ok'=>false, 'error'=>'نرخ معتبر USDTIRT از نوبیتکس دریافت نشد.'];
    return ['ok'=>true, 'ask'=>$ask, 'bid'=>$bid, 'last'=>(float)($data['lastTradePrice'] ?? 0), 'at'=>date('c')];
}
function token_mint_from_gecko($id): string {
    $s = (string)$id;
    return (strpos($s, 'solana_') === 0) ? substr($s, 7) : '';
}
function collect_candidate_mints(): array {
    $items = []; $counts = ['recent'=>0,'profiles'=>0,'boosts'=>0,'gecko'=>0];
    // Jupiter recent list is useful for genuinely new first pools.
    $j = http_json('https://api.jup.ag/tokens/v2/recent', [], 6);
    if ($j['ok'] && isset($j['data']) && is_array($j['data'])) {
        foreach ($j['data'] as $t) {
            $mint = (string)($t['id'] ?? '');
            if ($mint !== '' && !isset($items[$mint])) { $items[$mint] = ['mint'=>$mint,'source'=>'Jupiter recent','token'=>$t]; $counts['recent']++; }
            if ($counts['recent'] >= 12) break;
        }
    }
    foreach ([
        'https://api.dexscreener.com/token-profiles/latest/v1' => ['label'=>'DEX latest profile','key'=>'profiles','limit'=>8],
        'https://api.dexscreener.com/token-boosts/latest/v1' => ['label'=>'DEX latest boost','key'=>'boosts','limit'=>5],
    ] as $url=>$meta) {
        $r = http_json($url, [], 5);
        if (!$r['ok'] || !is_array($r['data'])) continue;
        foreach ($r['data'] as $row) {
            if (($row['chainId'] ?? '') !== 'solana') continue;
            $mint = (string)($row['tokenAddress'] ?? '');
            if ($mint !== '' && !isset($items[$mint])) { $items[$mint] = ['mint'=>$mint,'source'=>$meta['label'],'token'=>null]; $counts[$meta['key']]++; }
            if ($counts[$meta['key']] >= $meta['limit']) break;
        }
    }
    $g = http_json('https://api.geckoterminal.com/api/v2/networks/solana/new_pools?page=1', ['Accept: application/json;version=20230302'], 5);
    if ($g['ok'] && isset($g['data']) && is_array($g['data'])) {
        foreach (array_slice($g['data'], 0, 10) as $pool) {
            $rel = $pool['relationships']['base_token']['data']['id'] ?? '';
            $mint = token_mint_from_gecko($rel);
            if ($mint !== '' && !isset($items[$mint])) { $items[$mint] = ['mint'=>$mint,'source'=>'GeckoTerminal new pool','token'=>null]; $counts['gecko']++; }
            if ($counts['gecko'] >= 5) break;
        }
    }
    return array_slice(array_values($items), 0, 30);
}
function enrich_jupiter_tokens(array $candidates, array $config): array {
    $mints = array_values(array_unique(array_map(function($x){return (string)$x['mint'];}, $candidates)));
    if (!$mints) return [];
    $url = 'https://api.jup.ag/tokens/v2/search?query=' . rawurlencode(implode(',', array_slice($mints,0,100)));
    $headers = [];
    if (!empty($config['jupiter_api_key'])) $headers[] = 'x-api-key: ' . trim((string)$config['jupiter_api_key']);
    else usleep(2100000); // Jupiter keyless allowance is 0.5 requests/second.
    $r = http_json($url, $headers, 7);
    if (!$r['ok'] || !is_array($r['data'])) return [];
    $map = [];
    foreach ($r['data'] as $token) {
        $mint = (string)($token['id'] ?? '');
        if ($mint !== '') $map[$mint] = $token;
    }
    return $map;
}
function dex_pair_for_token(string $mint): ?array {
    $r = http_json('https://api.dexscreener.com/token-pairs/v1/solana/' . rawurlencode($mint), [], 10);
    if (!$r['ok'] || !is_array($r['data'])) return null;
    $best = null; $bestLiq = -1;
    foreach ($r['data'] as $pair) {
        if (($pair['chainId'] ?? '') !== 'solana') continue;
        $liq = (float)($pair['liquidity']['usd'] ?? 0);
        $price = (float)($pair['priceUsd'] ?? 0);
        if ($liq > $bestLiq && $price > 0) { $best = $pair; $bestLiq = $liq; }
    }
    return $best;
}
function dex_pairs_for_tokens(array $mints): array {
    $mints = array_values(array_unique(array_filter(array_map('strval',$mints))));
    if (!$mints) return [];
    $mints = array_slice($mints,0,30);
    $encoded = implode(',', array_map('rawurlencode',$mints));
    $r = http_json('https://api.dexscreener.com/tokens/v1/solana/' . $encoded, [], 8);
    if (!$r['ok'] || !is_array($r['data'])) return [];
    $wanted = array_fill_keys($mints,true); $best=[]; $liquidities=[];
    foreach ($r['data'] as $pair) {
        if (($pair['chainId'] ?? '') !== 'solana') continue;
        $mint = (string)($pair['baseToken']['address'] ?? '');
        if ($mint === '' || !isset($wanted[$mint])) continue;
        $liquidity = (float)($pair['liquidity']['usd'] ?? 0);
        if (!isset($liquidities[$mint]) || $liquidity > $liquidities[$mint]) { $best[$mint]=$pair; $liquidities[$mint]=$liquidity; }
    }
    return $best;
}
function token_market_data(array $candidate, ?array $jupiter, ?array $pair): array {
    $mint = (string)$candidate['mint'];
    $audit = is_array($jupiter['audit'] ?? null) ? $jupiter['audit'] : null;
    $dexPrice = (float)($pair['priceUsd'] ?? 0);
    $jupPrice = (float)($jupiter['usdPrice'] ?? 0);
    $price = $dexPrice > 0 ? $dexPrice : $jupPrice;
    $liquidity = (float)($pair['liquidity']['usd'] ?? ($jupiter['liquidity'] ?? 0));
    $vol5 = (float)($pair['volume']['m5'] ?? ($jupiter['stats5m']['volume'] ?? 0));
    $vol1h = (float)($pair['volume']['h1'] ?? ($jupiter['stats1h']['volume'] ?? 0));
    $buys = (int)($pair['txns']['m5']['buys'] ?? ($jupiter['stats5m']['numBuys'] ?? 0));
    $sells = (int)($pair['txns']['m5']['sells'] ?? ($jupiter['stats5m']['numSells'] ?? 0));
    $change5 = (float)($pair['priceChange']['m5'] ?? ($jupiter['stats5m']['priceChange'] ?? 0));
    $change1h = (float)($pair['priceChange']['h1'] ?? ($jupiter['stats1h']['priceChange'] ?? 0));
    $created = (int)($pair['pairCreatedAt'] ?? 0);
    $ageMin = $created > 0 ? max(0, (time() - (int)floor($created/1000))/60) : null;
    $name = (string)($jupiter['name'] ?? ($pair['baseToken']['name'] ?? 'Unknown'));
    $symbol = (string)($jupiter['symbol'] ?? ($pair['baseToken']['symbol'] ?? '—'));
    $topHolders = isset($audit['topHoldersPercentage']) ? (float)$audit['topHoldersPercentage'] : null;
    return [
        'mint'=>$mint, 'name'=>$name, 'symbol'=>$symbol, 'price_usd'=>$price, 'dex_price_usd'=>$dexPrice, 'jupiter_price_usd'=>$jupPrice, 'liquidity_usd'=>$liquidity,
        'volume_5m_usd'=>$vol5, 'volume_1h_usd'=>$vol1h, 'buys_5m'=>$buys, 'sells_5m'=>$sells,
        'change_5m_pct'=>$change5, 'change_1h_pct'=>$change1h, 'age_minutes'=>$ageMin,
        'organic_score'=>isset($jupiter['organicScore']) ? (float)$jupiter['organicScore'] : null,
        'holder_count'=>isset($jupiter['holderCount']) ? (int)$jupiter['holderCount'] : null,
        'is_verified'=>isset($jupiter['isVerified']) ? (bool)$jupiter['isVerified'] : null,
        'verification'=>strtolower((string)($jupiter['verification'] ?? '')),
        'audit'=>$audit, 'top_holders_pct'=>$topHolders,
        'pair_address'=>(string)($pair['pairAddress'] ?? ''), 'dex_url'=>(string)($pair['url'] ?? ''),
        'source'=>(string)$candidate['source'], 'updated_at'=>date('c')
    ];
}
function analyze_token(array $m): array {
    $reasons = []; $blocks = []; $score = 0;
    $liquidity = (float)$m['liquidity_usd']; $vol5 = (float)$m['volume_5m_usd'];
    $buys = (int)$m['buys_5m']; $sells = (int)$m['sells_5m'];
    $buyRatio = $sells > 0 ? $buys / $sells : ($buys > 0 ? 3.0 : 0.0);
    $organic = $m['organic_score']; $holders = $m['holder_count']; $audit = $m['audit'];
    if ((float)$m['price_usd'] <= 0) $blocks[] = 'قیمت معتبر دریافت نشد';
    if (trim((string)($m['pair_address'] ?? '')) === '') $blocks[] = 'استخر معاملاتی معتبر در DEX Screener پیدا نشد';
    if ((float)($m['dex_price_usd'] ?? 0) > 0 && (float)($m['jupiter_price_usd'] ?? 0) > 0) {
        $gap = abs((float)$m['dex_price_usd'] - (float)$m['jupiter_price_usd']) / max(0.000000001, (float)$m['jupiter_price_usd']) * 100;
        if ($gap > 8) $blocks[] = 'اختلاف قیمت DEX و Jupiter بیشتر از ۸٪ است';
    }
    if ($liquidity < 10000) $blocks[] = 'نقدینگی کمتر از ۱۰٬۰۰۰ دلار';
    if ($vol5 < 500) $blocks[] = 'حجم معاملات ۵ دقیقه کمتر از ۵۰۰ دلار';
    if ($buys < 8) $blocks[] = 'تعداد خریدهای ۵ دقیقه کافی نیست';
    if ($buyRatio < 1.20) $blocks[] = 'فشار خرید نسبت به فروش ضعیف است';
    if ($m['change_5m_pct'] < -1 || $m['change_5m_pct'] > 22) $blocks[] = 'تغییر قیمت ۵ دقیقه خارج از محدوده ورود است';
    if ($m['age_minutes'] === null) $blocks[] = 'سن استخر نامشخص است';
    elseif ($m['age_minutes'] < 2 || $m['age_minutes'] > 1440) $blocks[] = 'سن استخر خارج از محدوده مجاز است';
    if ($audit === null) $blocks[] = 'داده ممیزی امنیت توکن موجود نیست';
    else {
        if (($audit['mintAuthorityDisabled'] ?? null) !== true) $blocks[] = 'اختیار ایجاد توکن غیرفعال نشده یا نامشخص است';
        if (($audit['freezeAuthorityDisabled'] ?? null) !== true) $blocks[] = 'اختیار فریز توکن غیرفعال نشده یا نامشخص است';
        if (array_key_exists('isSus', $audit) && $audit['isSus']) $blocks[] = 'Jupiter توکن را مشکوک علامت‌گذاری کرده است';
        if ($m['top_holders_pct'] === null) $blocks[] = 'درصد تمرکز هولدرهای بزرگ نامشخص است';
        elseif ($m['top_holders_pct'] > 35) $blocks[] = 'تمرکز هولدرهای بزرگ بیشتر از ۳۵٪ است';
    }
    if ($organic === null) $blocks[] = 'امتیاز فعالیت ارگانیک موجود نیست';
    elseif ($organic < 25) $blocks[] = 'امتیاز فعالیت ارگانیک کمتر از ۲۵ است';
    if ($holders === null) $blocks[] = 'تعداد هولدرها نامشخص است';
    elseif ($holders < 20) $blocks[] = 'تعداد هولدرها کمتر از ۲۰ است';
    if ($m['verification'] === 'banned') $blocks[] = 'توکن در وضعیت ممنوع قرار دارد';

    // Explainable score, only used after hard safety/risk gates.
    $score += min(20, max(0, $liquidity / 2500));
    $score += min(20, max(0, $vol5 / 250));
    $score += min(20, max(0, ($buyRatio - 1.0) * 12));
    $score += $organic === null ? 0 : min(20, max(0, $organic / 4.5));
    $score += $holders === null ? 0 : min(10, max(0, $holders / 50));
    $score += min(10, max(0, $m['change_5m_pct'] * 0.65));
    $score = (int)round(min(100, $score));
    $reasons[] = 'نقدینگی: $' . number_format($liquidity,0);
    $reasons[] = 'حجم ۵ دقیقه: $' . number_format($vol5,0);
    $reasons[] = 'نسبت خرید به فروش: ' . number_format($buyRatio,2);
    $reasons[] = 'تغییر قیمت ۵ دقیقه: ' . number_format((float)$m['change_5m_pct'],2) . '%';
    if ($organic !== null) $reasons[] = 'امتیاز ارگانیک Jupiter: ' . number_format((float)$organic,1);
    if ($m['top_holders_pct'] !== null) $reasons[] = 'سهم ۱۰ هولدر بزرگ: ' . number_format((float)$m['top_holders_pct'],1) . '%';
    return ['score'=>$score, 'buy_ratio'=>$buyRatio, 'eligible'=>count($blocks)===0 && $score >= 70, 'blocks'=>$blocks, 'reasons'=>$reasons];
}
function estimate_slippage_pct(float $tradeUsd, float $liquidityUsd): float {
    if ($liquidityUsd <= 0) return 3.0;
    return min(3.0, max(0.35, 0.35 + (($tradeUsd / $liquidityUsd) * 100 * 0.75)));
}
function current_equity_usdt(array $state): float {
    $total = (float)($state['cash_usdt'] ?? 0);
    foreach (($state['positions'] ?? []) as $p) {
        $px = (float)($p['last_price_usd'] ?? $p['entry_price_usd'] ?? 0);
        $qty = (float)($p['token_qty'] ?? 0);
        $grossMark = $qty * $px;
        $liq = max(1, (float)($p['liquidity_usd'] ?? 1));
        $slippage = estimate_slippage_pct($grossMark, $liq);
        $gross = $grossMark * (1 - $slippage/100) * (1 - ((float)($state['config_snapshot']['trade_fee_pct'] ?? 0.30)/100));
        $total += max(0, $gross - (float)($state['config_snapshot']['network_fee_usdt'] ?? 0.0005));
    }
    return $total;
}
function save_decision(array &$state, array $market, array $analysis, string $action, string $reason): void {
    $mint = $market['mint'];
    $row = ['at'=>date('c'),'mint'=>$mint,'symbol'=>$market['symbol'],'name'=>$market['name'],'price_usd'=>$market['price_usd'],'score'=>$analysis['score'],'action'=>$action,'reason'=>$reason,'blocks'=>$analysis['blocks'],'positive_reasons'=>$analysis['reasons'],'source'=>$market['source'],'dex_url'=>$market['dex_url'] ?? '','pair_address'=>$market['pair_address'] ?? ''];
    $old = $state['decisions'][$mint] ?? null;
    $signature = hash('sha256', json_encode([$row['action'],$row['score'],$row['blocks'],$row['reason']]));
    $lastAt = isset($old['at']) ? strtotime($old['at']) : 0;
    $oldSig = (string)($old['signature'] ?? '');
    $state['decisions'][$mint] = $row + ['signature'=>$signature];
    if ($oldSig !== $signature || time() - $lastAt >= 1800) append_jsonl('decisions.jsonl', $row);
}
function open_paper_position(array &$state, array $market, array $analysis, array $config): ?array {
    $equity = current_equity_usdt($state);
    $score = (int)$analysis['score'];
    $pct = $score >= 90 ? 8.0 : ($score >= 82 ? 6.0 : 4.0);
    $stake = min((float)$state['cash_usdt'] * 0.80, $equity * ($pct/100));
    if ($stake < 0.10) return null;
    $liquidity = (float)$market['liquidity_usd'];
    $slip = estimate_slippage_pct($stake, $liquidity);
    $feePct = (float)$config['trade_fee_pct'];
    $netForTokens = $stake * (1 - $feePct/100) - (float)$config['network_fee_usdt'];
    if ($netForTokens <= 0) return null;
    $entry = (float)$market['price_usd'] * (1 + $slip/100);
    if ($entry <= 0) return null;
    $qty = $netForTokens / $entry;
    $id = bin2hex(random_bytes(8));
    $position = [
        'id'=>$id,'mint'=>$market['mint'],'symbol'=>$market['symbol'],'name'=>$market['name'],
        'opened_at'=>date('c'),'cost_usdt'=>$stake,'token_qty'=>$qty,'entry_price_usd'=>$entry,
        'entry_market_price_usd'=>(float)$market['price_usd'],'last_price_usd'=>(float)$market['price_usd'],
        'peak_price_usd'=>(float)$market['price_usd'],'entry_slippage_pct'=>$slip,'liquidity_usd'=>$liquidity,
        'buy_fee_usdt'=>$stake*$feePct/100,'network_fee_buy_usdt'=>(float)$config['network_fee_usdt'],
        'score_at_entry'=>$score,'entry_reasons'=>$analysis['reasons'],'pair_address'=>$market['pair_address']
    ];
    $state['cash_usdt'] -= $stake;
    $state['positions'][$market['mint']] = $position;
    $trade = ['id'=>$id,'type'=>'BUY','at'=>date('c'),'mint'=>$market['mint'],'symbol'=>$market['symbol'],'name'=>$market['name'],'market_price_usd'=>(float)$market['price_usd'],'execution_price_usd'=>$entry,'amount_usdt'=>$stake,'token_qty'=>$qty,'fee_usdt'=>$position['buy_fee_usdt'],'network_fee_usdt'=>$position['network_fee_buy_usdt'],'slippage_pct'=>$slip,'score'=>$score,'signal_reasons'=>$analysis['reasons'],'reason'=>'سیگنال واجد شرایط؛ امتیاز '.$score.' از ۱۰۰.'];
    $state['trades'][] = $trade;
    append_jsonl('trades.jsonl', $trade);
    log_event('INFO', 'معامله آزمایشی خرید باز شد', ['symbol'=>$market['symbol'],'mint'=>$market['mint'],'stake_usdt'=>$stake,'score'=>$score]);
    telegram_send($config, "🟢 خرید آزمایشی {$market['symbol']}\nمبلغ: $" . number_format($stake,2) . "\nامتیاز: {$score}/100\nقیمت: $" . $market['price_usd']);
    return $trade;
}
function close_paper_position(array &$state, string $mint, array $market, string $reason, array $config): ?array {
    if (!isset($state['positions'][$mint])) return null;
    $p = $state['positions'][$mint];
    $marketPrice = (float)($market['price_usd'] ?? $p['last_price_usd']);
    if ($marketPrice <= 0) return null;
    $liquidity = max(1, (float)($market['liquidity_usd'] ?? $p['liquidity_usd']));
    $grossMark = (float)$p['token_qty'] * $marketPrice;
    $slip = estimate_slippage_pct($grossMark, $liquidity);
    $execution = $marketPrice * (1 - $slip/100);
    $gross = (float)$p['token_qty'] * $execution;
    $fee = $gross * ((float)$config['trade_fee_pct']/100);
    $network = (float)$config['network_fee_usdt'];
    $net = max(0, $gross - $fee - $network);
    $pnl = $net - (float)$p['cost_usdt'];
    $roi = $p['cost_usdt'] > 0 ? ($pnl / (float)$p['cost_usdt']) * 100 : 0;
    $state['cash_usdt'] += $net;
    unset($state['positions'][$mint]);
    $trade = ['id'=>$p['id'],'type'=>'SELL','at'=>date('c'),'opened_at'=>$p['opened_at'],'mint'=>$mint,'symbol'=>$p['symbol'],'name'=>$p['name'],'market_price_usd'=>$marketPrice,'execution_price_usd'=>$execution,'amount_usdt'=>(float)$p['cost_usdt'],'gross_usdt'=>$gross,'fee_usdt'=>$fee,'network_fee_usdt'=>$network,'slippage_pct'=>$slip,'net_proceeds_usdt'=>$net,'pnl_usdt'=>$pnl,'roi_pct'=>$roi,'reason'=>$reason,'score_at_entry'=>$p['score_at_entry'],'entry_reasons'=>$p['entry_reasons']];
    $state['trades'][] = $trade;
    $state['closed_tokens'][$mint] = time() + 5400;
    append_jsonl('trades.jsonl', $trade);
    log_event('INFO', 'معامله آزمایشی بسته شد', ['symbol'=>$p['symbol'],'pnl_usdt'=>$pnl,'roi_pct'=>$roi,'reason'=>$reason]);
    $emoji = $pnl >= 0 ? '✅' : '🔴';
    telegram_send($config, $emoji . " فروش آزمایشی {$p['symbol']}\nنتیجه: " . number_format($pnl,4) . " USDT (" . number_format($roi,2) . "%)\nعلت: {$reason}");
    return $trade;
}
function run_paper_engine(): array {
    $config = app_config();
    if (!$config || !is_installed()) return ['ok'=>false,'message'=>'ربات هنوز نصب نشده است.'];
    $lock = @fopen(store_path('cron.lock'), 'c+');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) return ['ok'=>false,'message'=>'اجرای قبلی هنوز تمام نشده؛ این نوبت رد شد.'];
    $started = microtime(true);
    try {
        $state = json_read('state.json', []);
        if (!$state) $state = ['initialized'=>false,'positions'=>[],'trades'=>[],'decisions'=>[],'closed_tokens'=>[],'cash_usdt'=>0.0];
        $fx = get_usdt_irt_rate();
        if ($fx['ok']) $state['latest_fx'] = $fx;
        else log_event('WARN', 'دریافت نرخ USDT/IRT ناموفق بود', ['error'=>$fx['error']]);
        if (empty($state['initialized'])) {
            if (!$fx['ok']) { $state['last_run']=['at'=>date('c'),'status'=>'waiting_fx','message'=>'تا دریافت نرخ معتبر تتر، سرمایه اولیه تبدیل نمی‌شود.']; json_write('state.json',$state); return ['ok'=>false,'message'=>'نرخ تتر دریافت نشد؛ شروع سرمایه‌گذاری آزمایشی به تعویق افتاد.']; }
            $initial = (float)$config['initial_toman'];
            $feePct = (float)$config['usdt_conversion_fee_pct'];
            $usdtGross = $initial / (float)$fx['ask'];
            $usdtNet = $usdtGross * (1 - $feePct/100);
            $state['initialized'] = true;
            $state['started_at'] = date('c');
            $state['initial_toman'] = $initial;
            $state['initial_fx_ask'] = (float)$fx['ask'];
            $state['initial_usdt_gross'] = $usdtGross;
            $state['initial_usdt_net'] = $usdtNet;
            $state['initial_conversion_fee_usdt'] = $usdtGross - $usdtNet;
            $state['cash_usdt'] = $usdtNet;
            $state['positions'] = $state['positions'] ?? [];
            $state['trades'] = $state['trades'] ?? [];
            $state['decisions'] = $state['decisions'] ?? [];
            $state['closed_tokens'] = [];
            $state['config_snapshot'] = ['trade_fee_pct'=>(float)$config['trade_fee_pct'],'network_fee_usdt'=>(float)$config['network_fee_usdt']];
            $state['daily_baselines'][date('Y-m-d')] = $usdtNet;
            $conversion = ['id'=>bin2hex(random_bytes(8)),'type'=>'CONVERT','at'=>date('c'),'symbol'=>'USDT','name'=>'تبدیل فرضی تومان به تتر','amount_toman'=>$initial,'fx_rate_toman_per_usdt'=>(float)$fx['ask'],'usdt_gross'=>$usdtGross,'conversion_fee_pct'=>$feePct,'fee_usdt'=>$usdtGross-$usdtNet,'amount_usdt'=>$usdtNet,'reason'=>'تبدیل آزمایشی سرمایه اولیه با نرخ فروش USDT در اردربوک عمومی Nobitex؛ بدون سفارش واقعی.'];
            $state['trades'][] = $conversion;
            append_jsonl('trades.jsonl',$conversion);
            log_event('INFO','حساب Paper Trading با تبدیل فرضی تومان به USDT ساخته شد',['initial_toman'=>$initial,'fx_ask'=>$fx['ask'],'cash_usdt'=>$usdtNet]);
            telegram_send($config, "🚀 ربات شکار پامپ فعال شد\nسرمایه فرضی: " . number_format($initial) . " تومان\nنرخ فرضی USDT: " . number_format((float)$fx['ask']) . " تومان\nموجودی اولیه: " . number_format($usdtNet,4) . " USDT");
        }
        $state['config_snapshot'] = ['trade_fee_pct'=>(float)$config['trade_fee_pct'],'network_fee_usdt'=>(float)$config['network_fee_usdt']];
        $currentDay = date('Y-m-d');
        if (!isset($state['daily_baselines'][$currentDay])) $state['daily_baselines'][$currentDay] = current_equity_usdt($state);
        // Refresh open positions first.
        $openMints = array_keys($state['positions'] ?? []);
        $marketMap = [];
        $discovered = collect_candidate_mints();
        $candidateMints = array_map(function($c){ return (string)$c['mint']; }, $discovered);
        $dexPairMap = dex_pairs_for_tokens(array_merge($openMints,$candidateMints));
        foreach ($openMints as $mint) {
            $pair = $dexPairMap[$mint] ?? null;
            if ($pair) {
                $m = token_market_data(['mint'=>$mint,'source'=>'open position'], null, $pair);
                if ($m['price_usd'] > 0) {
                    $state['positions'][$mint]['last_price_usd'] = $m['price_usd'];
                    $state['positions'][$mint]['peak_price_usd'] = max((float)$state['positions'][$mint]['peak_price_usd'], $m['price_usd']);
                    $state['positions'][$mint]['liquidity_usd'] = $m['liquidity_usd'] ?: $state['positions'][$mint]['liquidity_usd'];
                    $state['positions'][$mint]['last_seen_at'] = date('c');
                    $marketMap[$mint] = $m;
                }
            }
        }
        foreach (array_keys($state['positions'] ?? []) as $mint) {
            // Never simulate an exit at a stale quote; wait for a fresh DEX pool observation.
            if (!isset($marketMap[$mint])) continue;
            $p = $state['positions'][$mint];
            $m = $marketMap[$mint];
            $price = (float)$m['price_usd'];
            if ($price <= 0) continue;
            $peak = max((float)$p['peak_price_usd'], $price);
            $qty = (float)$p['token_qty'];
            $slipNow = estimate_slippage_pct($qty*$price, max(1,(float)($m['liquidity_usd'] ?? $p['liquidity_usd'])));
            $netMark = $qty*$price*(1-$slipNow/100)*(1-(float)$config['trade_fee_pct']/100) - (float)$config['network_fee_usdt'];
            $roi = ((($netMark-(float)$p['cost_usdt']) / max(0.000001,(float)$p['cost_usdt']))*100);
            $peakRoi = (((($qty*$peak*(1-$slipNow/100)*(1-(float)$config['trade_fee_pct']/100))-(float)$p['cost_usdt'])/max(0.000001,(float)$p['cost_usdt']))*100);
            $opened = strtotime((string)$p['opened_at']) ?: time();
            $ageHours = (time()-$opened)/3600;
            $reason = '';
            if ($roi <= -12.0) $reason = 'حد ضرر: زیان خالص به ۱۲٪ رسید';
            elseif ($roi >= 35.0) $reason = 'حد سود: سود خالص به ۳۵٪ رسید';
            elseif ($peakRoi >= 18.0 && $price <= $peak*0.90) $reason = 'حدضرر متحرک: افت ۱۰٪ از سقف قیمت پس از رشد';
            elseif ($ageHours >= 24) $reason = 'حداکثر زمان نگهداری ۲۴ ساعت';
            elseif (isset($m['change_5m_pct']) && (float)$m['change_5m_pct'] <= -8 && (int)($m['sells_5m'] ?? 0) > 0 && (int)($m['buys_5m'] ?? 0) < (int)($m['sells_5m'] ?? 0)) $reason = 'برگشت شدید مومنتوم و غلبه فروشندگان';
            if ($reason !== '') close_paper_position($state, $mint, $m, $reason, $config);
        }
        // Discover and evaluate candidates. Keep calls bounded for a shared cPanel host.
        $candidates = array_slice($discovered, 0, max(0, 30 - count($openMints)));
        $tokenMap = enrich_jupiter_tokens($candidates, $config);
        $processed = 0; $bought = 0; $eligibleCount = 0;
        foreach ($candidates as $candidate) {
            $mint = $candidate['mint'];
            if (isset($state['positions'][$mint])) continue;
            $jtoken = $tokenMap[$mint] ?? ($candidate['token'] ?? null);
            if (!is_array($jtoken)) {
                $dummy = ['mint'=>$mint,'name'=>'Unknown','symbol'=>substr($mint,0,6),'price_usd'=>0,'liquidity_usd'=>0,'volume_5m_usd'=>0,'volume_1h_usd'=>0,'buys_5m'=>0,'sells_5m'=>0,'change_5m_pct'=>0,'change_1h_pct'=>0,'age_minutes'=>null,'organic_score'=>null,'holder_count'=>null,'is_verified'=>null,'verification'=>'','audit'=>null,'top_holders_pct'=>null,'pair_address'=>'','dex_url'=>'','source'=>$candidate['source']];
                $a = analyze_token($dummy); $a['blocks'][] = 'اطلاعات توکن از Jupiter دریافت نشد'; save_decision($state,$dummy,$a,'SKIP','داده بنیادی/امنیتی در دسترس نیست'); continue;
            }
            $pair = $dexPairMap[$mint] ?? null;
            $market = token_market_data($candidate, $jtoken, $pair);
            $analysis = analyze_token($market);
            $processed++;
            $cooldown = (int)($state['closed_tokens'][$mint] ?? 0);
            if ($cooldown > time()) { $analysis['eligible']=false; $analysis['blocks'][]='دوره توقف ۹۰ دقیقه‌ای پس از معامله قبلی'; }
            $equity = current_equity_usdt($state);
            $today = date('Y-m-d');
            $realizedToday = 0.0;
            foreach (($state['trades'] ?? []) as $t) if (($t['type'] ?? '')==='SELL' && substr((string)($t['at'] ?? ''),0,10)===$today) $realizedToday += (float)($t['pnl_usdt'] ?? 0);
            $dayBaseline = (float)($state['daily_baselines'][$today] ?? $state['initial_usdt_net']);
            $lossLimit = max(0.01, $dayBaseline * ((float)$config['max_daily_loss_pct']/100));
            $equityDrawdownToday = current_equity_usdt($state) - $dayBaseline;
            if ($realizedToday <= -$lossLimit || $equityDrawdownToday <= -$lossLimit) { $analysis['eligible']=false; $analysis['blocks'][]='توقف ورود جدید: سقف زیان روزانه فعال شده'; }
            if (empty($config['trading_enabled'])) { $analysis['eligible']=false; $analysis['blocks'][]='ورود معاملات آزمایشی در تنظیمات غیرفعال است'; }
            if (count($state['positions']) >= (int)$config['max_open_positions']) { $analysis['eligible']=false; $analysis['blocks'][]='حداکثر تعداد موقعیت‌های باز پر است'; }
            if ($state['cash_usdt'] < 0.10) { $analysis['eligible']=false; $analysis['blocks'][]='موجودی نقد USDT کافی نیست'; }
            if ($analysis['eligible']) {
                $eligibleCount++;
                $trade = open_paper_position($state,$market,$analysis,$config);
                if ($trade) { $bought++; save_decision($state,$market,$analysis,'BUY','خرید آزمایشی انجام شد؛ امتیاز و تمام فیلترها تأیید شدند.'); }
                else save_decision($state,$market,$analysis,'SKIP','اندازه معامله از حداقل مجاز کمتر بود.');
            } else {
                $reason = implode('؛ ', $analysis['blocks']);
                save_decision($state,$market,$analysis,'SKIP',$reason !== '' ? $reason : 'امتیاز کمتر از حد ورود است.');
            }
        }
        // Expire cooldowns and maintain recent history size.
        foreach (($state['closed_tokens'] ?? []) as $mint=>$until) if ((int)$until <= time()) unset($state['closed_tokens'][$mint]);
        if (count($state['trades']) > 3000) $state['trades'] = array_slice($state['trades'], -3000);
        if (count($state['decisions']) > 1000) $state['decisions'] = array_slice($state['decisions'], -1000, null, true);
        $equity = current_equity_usdt($state);
        $state['last_run'] = ['at'=>date('c'),'status'=>'ok','duration_seconds'=>round(microtime(true)-$started,2),'candidates'=>count($candidates),'evaluated'=>$processed,'eligible'=>$eligibleCount,'bought'=>$bought,'open_positions'=>count($state['positions']),'cash_usdt'=>(float)$state['cash_usdt'],'equity_usdt'=>$equity,'fx_rate'=>$fx['ok'] ? (float)$fx['ask'] : (float)($state['latest_fx']['ask'] ?? 0)];
        // Daily equity snapshots: latest observation replaces current day's row.
        $daily = json_read('daily.json', []);
        $day = date('Y-m-d');
        $daily[$day] = ['date'=>$day,'start_equity_usdt'=>(float)($state['daily_baselines'][$day] ?? $state['initial_usdt_net']),'equity_usdt'=>$equity,'equity_toman'=>($fx['ok'] ? $equity*(float)$fx['bid'] : ($equity*(float)($state['latest_fx']['bid'] ?? 0))),'fx_rate_toman'=>(float)($state['latest_fx']['bid'] ?? 0),'cash_usdt'=>(float)$state['cash_usdt'],'open_positions'=>count($state['positions']),'realized_pnl_usdt'=>daily_realized_pnl($state,$day),'updated_at'=>date('c')];
        json_write('daily.json', $daily);
        json_write('state.json', $state);
        log_event('INFO','اجرای کران کامل شد',['duration'=>$state['last_run']['duration_seconds'],'candidates'=>count($candidates),'evaluated'=>$processed,'bought'=>$bought,'equity_usdt'=>$equity]);
        // One daily Telegram report near local midnight (23:55 or later).
        if (date('H:i') >= '23:55' && ($state['daily_report_sent'] ?? '') !== $day) {
            $report = "📊 گزارش روزانه Paper Trading\nتاریخ: {$day}\nارزش حساب: $" . number_format($equity,4) . " USDT\nارزش تومانی: " . number_format((float)($state['latest_fx']['bid'] ?? 0)*$equity,0) . " تومان\nموجودی نقد: $" . number_format((float)$state['cash_usdt'],4) . "\nموقعیت باز: " . count($state['positions']) . "\nسود/زیان بسته‌شده امروز: $" . number_format(daily_realized_pnl($state,$day),4);
            telegram_send($config,$report); $state['daily_report_sent']=$day; json_write('state.json',$state);
        }
        return ['ok'=>true,'message'=>'اجرا کامل شد.','stats'=>$state['last_run']];
    } catch (Throwable $e) {
        log_event('ERROR','خطای اجرای موتور',['error'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()]);
        return ['ok'=>false,'message'=>'خطای موتور: '.$e->getMessage()];
    } finally {
        if (is_resource($lock)) { flock($lock, LOCK_UN); fclose($lock); }
    }
}
function daily_realized_pnl(array $state, string $day): float {
    $sum=0.0;
    foreach (($state['trades'] ?? []) as $t) if (($t['type'] ?? '')==='SELL' && substr((string)($t['at'] ?? ''),0,10)===$day) $sum+=(float)($t['pnl_usdt'] ?? 0);
    return $sum;
}
