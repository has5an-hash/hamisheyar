<?php
declare(strict_types=1);
require_once __DIR__ . '/app/common.php';
date_default_timezone_set('Asia/Tehran');
if (!is_installed()) redirect('install.php'); require_login();
$config=app_config(); $notice=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $config['max_open_positions']=max(1,min(8,(int)($_POST['max_open_positions'] ?? 4)));
    $config['max_daily_loss_pct']=max(1,min(15,(float)($_POST['max_daily_loss_pct'] ?? 5)));
    $config['trade_fee_pct']=max(0,min(2,(float)($_POST['trade_fee_pct'] ?? .3)));
    $config['usdt_conversion_fee_pct']=max(0,min(2,(float)($_POST['usdt_conversion_fee_pct'] ?? .2)));
    $config['network_fee_usdt']=max(0,min(.05,(float)($_POST['network_fee_usdt'] ?? .0005)));
    $config['trading_enabled']=isset($_POST['trading_enabled']);
    $config['jupiter_api_key']=trim((string)($_POST['jupiter_api_key'] ?? ''));
    $config['telegram_bot_token']=trim((string)($_POST['telegram_bot_token'] ?? ''));
    $config['telegram_chat_id']=trim((string)($_POST['telegram_chat_id'] ?? ''));
    $new=(string)($_POST['new_password'] ?? '');
    if ($new!=='') {
        if (strlen($new)<12) $error='رمز جدید باید حداقل ۱۲ کاراکتر باشد.';
        else $config['admin_password_hash']=password_hash($new,PASSWORD_DEFAULT);
    }
    if (!$error && save_config($config)) $notice='تنظیمات ذخیره شد.';
    elseif (!$error) $error='ذخیره تنظیمات ناموفق بود.';
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تنظیمات Pump Hunter</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="shell"><header class="topbar"><div class="brand"><div class="brand-mark">D</div><div><strong>Developersia Pump Hunter</strong><small>تنظیمات ربات</small></div></div><nav><a href="index.php">داشبورد</a><a class="active" href="settings.php">تنظیمات</a><a href="logout.php">خروج</a></nav></header><main><div class="page-head"><div><div class="eyebrow">CONTROL PANEL</div><h1>تنظیمات مدیریت</h1><p>تغییر پارامترهای ریسک و گزارش‌دهی</p></div></div><?php if($notice): ?><div class="notice success"><?= h($notice) ?></div><?php endif; ?><?php if($error): ?><div class="notice danger"><?= h($error) ?></div><?php endif; ?><form method="post" class="panel settings-form"><input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>"><h2>مدیریت ریسک</h2><div class="form-grid"><label>حداکثر موقعیت باز<input type="number" name="max_open_positions" min="1" max="8" value="<?= (int)$config['max_open_positions'] ?>"></label><label>حد توقف ورود روزانه (٪)<input type="number" name="max_daily_loss_pct" min="1" max="15" step="0.5" value="<?= h($config['max_daily_loss_pct']) ?>"></label><label>کارمزد هر سمت معامله (٪)<input type="number" name="trade_fee_pct" min="0" max="2" step="0.01" value="<?= h($config['trade_fee_pct']) ?>"></label><label>کارمزد تبدیل اولیه USDT (٪)<input type="number" name="usdt_conversion_fee_pct" min="0" max="2" step="0.01" value="<?= h($config['usdt_conversion_fee_pct']) ?>"></label><label>هزینه تخمینی شبکه (USDT)<input type="number" name="network_fee_usdt" min="0" max="0.05" step="0.0001" value="<?= h($config['network_fee_usdt']) ?>"></label></div><label class="checkline"><input type="checkbox" name="trading_enabled" value="1" <?= !empty($config['trading_enabled'])?'checked':'' ?>> اجازه باز کردن معاملات آزمایشی جدید</label><p class="muted">خاموش کردن این گزینه، ورود جدید را متوقف می‌کند؛ مدیریت و خروج از موقعیت‌های باز ادامه خواهد داشت.</p><h2>اتصال‌ها و هشدارها</h2><div class="form-grid"><label>Jupiter API Key (اختیاری)<input type="password" name="jupiter_api_key" value="<?= h($config['jupiter_api_key'] ?? '') ?>" autocomplete="off"></label><label>Telegram Bot Token<input type="password" name="telegram_bot_token" value="<?= h($config['telegram_bot_token'] ?? '') ?>" autocomplete="off"></label><label>Telegram Chat ID<input type="text" name="telegram_chat_id" value="<?= h($config['telegram_chat_id'] ?? '') ?>"></label><label>تغییر رمز عبور پنل (اختیاری)<input type="password" name="new_password" minlength="12" autocomplete="new-password"></label></div><div class="button-row"><button class="btn primary" type="submit">ذخیره تنظیمات</button><a class="btn ghost" href="index.php">بازگشت به داشبورد</a></div></form><div class="footer-note">سرمایه اولیه پس از راه‌اندازی قابل تغییر نیست؛ برای شروع مجدد حساب باید داده‌های حساب ریست شوند که این نسخه برای جلوگیری از حذف ناخواسته، دکمه ریست عمومی ندارد.</div></main></div></body></html>
