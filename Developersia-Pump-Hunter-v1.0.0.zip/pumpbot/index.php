<?php
declare(strict_types=1);
require_once __DIR__ . '/app/engine.php';
date_default_timezone_set('Asia/Tehran');
if (!is_installed()) redirect('install.php');
require_login();
$config = app_config();
$state = json_read('state.json', []);
$daily = json_read('daily.json', []);
$apiHealth = json_read('api_health.json', []);
$trades = array_reverse($state['trades'] ?? []);
$decisions = array_reverse(array_values($state['decisions'] ?? []));
$fx = $state['latest_fx'] ?? [];
$fxBid = (float)($fx['bid'] ?? 0);
$equity = $state ? current_equity_usdt($state) : 0.0;
$cash = (float)($state['cash_usdt'] ?? 0);
$startNet = (float)($state['initial_usdt_net'] ?? 0);
$pnlUsdt = $state && !empty($state['initialized']) ? $equity - $startNet : 0;
$equityToman = $fxBid > 0 ? $equity * $fxBid : 0;
$pnlToman = $equityToman > 0 ? $equityToman - (float)($state['initial_toman'] ?? $config['initial_toman']) : 0;
$lastRun = $state['last_run'] ?? [];
$open = $state['positions'] ?? [];
$closed = array_values(array_filter($trades, function($t){ return ($t['type'] ?? '') === 'SELL'; }));
$wins = count(array_filter($closed, function($t){return (float)($t['pnl_usdt'] ?? 0) > 0;}));
$losses = count($closed) - $wins;
?><!doctype html>
<html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Developersia Pump Hunter</title><link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="shell">
<header class="topbar"><div class="brand"><div class="brand-mark">D</div><div><strong>Developersia Pump Hunter</strong><small>ربات شکار پامپ · معاملات آزمایشی</small></div></div><nav><a class="active" href="index.php">داشبورد</a><a href="settings.php">تنظیمات</a><a href="logout.php">خروج</a></nav></header>
<main>
<div class="page-head"><div><div class="eyebrow">SOLANA · PAPER TRADING</div><h1>داشبورد عملکرد ربات</h1><p>قیمت‌های زنده بازار، بدون انجام معامله واقعی</p></div><div class="status-pill <?= !empty($state['initialized']) ? 'ok' : 'warn' ?>"><i></i><?= !empty($state['initialized']) ? 'حساب آزمایشی فعال' : 'در انتظار اولین اجرای کران' ?></div></div>
<?php if (empty($state['initialized'])): ?>
<div class="notice warning"><b>شروع حساب هنوز انجام نشده است.</b><br>بعد از نصب، اولین اجرای Cron نرخ USDT/IRT را می‌گیرد و سرمایه فرضی <?= fa_num($config['initial_toman'],0) ?> تومان را پس از کسر کارمزد به USDT تبدیل می‌کند.</div>
<?php endif; ?>
<div class="grid metrics">
 <section class="metric primary"><span>ارزش کل حساب</span><strong>$<?= fa_num($equity,4) ?></strong><small><?= $equityToman ? fa_num($equityToman,0).' تومان' : 'تا دریافت نرخ تتر محاسبه نمی‌شود' ?></small></section>
 <section class="metric"><span>سود / زیان کل</span><strong class="<?= $pnlUsdt >= 0 ? 'positive':'negative' ?>"><?= $pnlUsdt >= 0 ? '+':'' ?>$<?= fa_num($pnlUsdt,4) ?></strong><small><?= $pnlToman >= 0 ? '+':'' ?><?= fa_num($pnlToman,0) ?> تومان نسبت به سرمایه اولیه</small></section>
 <section class="metric"><span>موجودی نقد USDT</span><strong>$<?= fa_num($cash,4) ?></strong><small>قابل استفاده برای خرید آزمایشی</small></section>
 <section class="metric"><span>موقعیت‌های باز</span><strong><?= count($open) ?> <em>/ <?= (int)$config['max_open_positions'] ?></em></strong><small>معاملات در حال پیگیری</small></section>
</div>
<div class="grid two-col">
<section class="panel"><div class="panel-title"><div><h2>وضعیت حساب</h2><p>اطلاعات تبدیل سرمایه و اجرای اخیر</p></div><span class="tag">زنده</span></div>
<div class="facts">
<div><span>سرمایه اولیه</span><b><?= fa_num($state['initial_toman'] ?? $config['initial_toman'],0) ?> تومان</b></div>
<div><span>نرخ خرید فرضی USDT</span><b><?= !empty($state['initial_fx_ask']) ? fa_num($state['initial_fx_ask'],0).' تومان' : '—' ?></b></div>
<div><span>موجودی اولیه پس از کارمزد</span><b><?= !empty($state['initial_usdt_net']) ? '$'.fa_num($state['initial_usdt_net'],4) : '—' ?></b></div>
<div><span>نرخ فعلی فروش USDT</span><b><?= $fxBid ? fa_num($fxBid,0).' تومان' : '—' ?></b></div>
<div><span>آخرین اجرای کران</span><b><?= !empty($lastRun['at']) ? h(fmt_date($lastRun['at'])) : 'هنوز اجرا نشده' ?></b></div>
<div><span>مدت آخرین اجرا</span><b><?= isset($lastRun['duration_seconds']) ? fa_num($lastRun['duration_seconds'],2).' ثانیه' : '—' ?></b></div>
<div><span>توکن‌های ارزیابی‌شده در آخرین اجرا</span><b><?= isset($lastRun['evaluated']) ? (int)$lastRun['evaluated'] : '—' ?></b></div>
<div><span>خرید آزمایشی در آخرین اجرا</span><b><?= isset($lastRun['bought']) ? (int)$lastRun['bought'] : '—' ?></b></div>
</div>
</section>
<section class="panel full-row"><div class="panel-title"><div><h2>سلامت منابع داده</h2><p>آخرین وضعیت ارتباط APIها</p></div></div>
<div class="facts">
<?php foreach (['apiv2.nobitex.ir'=>'نرخ تتر نوبیتکس','api.jup.ag'=>'توکن و ممیزی Jupiter','api.dexscreener.com'=>'بازار DEX Screener','api.geckoterminal.com'=>'استخرهای GeckoTerminal'] as $host=>$label): $health=$apiHealth[$host] ?? null; ?>
<div><span><?= h($label) ?></span><b class="<?= $health ? (!empty($health['ok'])?'positive':'negative') : '' ?>"><?= $health ? (!empty($health['ok'])?'متصل':'خطا') . ' · ' . h(fmt_date($health['at'])) : 'هنوز بررسی نشده' ?></b></div>
<?php endforeach; ?>
</div></section>
<section class="panel"><div class="panel-title"><div><h2>آمار معاملات</h2><p>بر اساس معاملات بسته‌شده</p></div></div>
<div class="stats-row"><div><strong><?= count($closed) ?></strong><span>معامله بسته‌شده</span></div><div><strong class="positive"><?= $wins ?></strong><span>سودده</span></div><div><strong class="negative"><?= $losses ?></strong><span>زیان‌ده</span></div><div><strong><?= count($closed) ? fa_num(($wins/count($closed))*100,1).'%' : '—' ?></strong><span>درصد برد</span></div></div>
<div class="muted-note">درصد برد به‌تنهایی معیار سوددهی نیست؛ سود خالص پس از تمام هزینه‌ها معیار اصلی است.</div>
</section>
</div>
<section class="panel"><div class="panel-title"><div><h2>موقعیت‌های باز</h2><p>قیمت آخرین مشاهده‌شده و بازده تخمینی</p></div><span class="tag"><?= count($open) ?> باز</span></div>
<?php if (!$open): ?><div class="empty">در حال حاضر موقعیت بازی وجود ندارد. ربات در اجرای بعدی بازار را بررسی می‌کند.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>توکن</th><th>قیمت ورود</th><th>قیمت فعلی</th><th>سرمایه</th><th>بازده تخمینی</th><th>زمان ورود</th></tr></thead><tbody>
<?php foreach ($open as $p): $px=(float)($p['last_price_usd'] ?? $p['entry_price_usd']); $gross=(float)$p['token_qty']*$px; $slip=estimate_slippage_pct($gross,max(1,(float)$p['liquidity_usd'])); $net=$gross*(1-$slip/100)*(1-(float)$config['trade_fee_pct']/100)-(float)$config['network_fee_usdt']; $roi=(((($net-(float)$p['cost_usdt'])/max(.000001,(float)$p['cost_usdt']))*100)); ?>
<tr><td><b><?= h($p['symbol']) ?></b><small class="subline"><?= h($p['name']) ?></small></td><td>$<?= fa_num($p['entry_price_usd'],8) ?></td><td>$<?= fa_num($px,8) ?></td><td>$<?= fa_num($p['cost_usdt'],3) ?></td><td class="<?= $roi>=0?'positive':'negative' ?>"><?= $roi>=0?'+':'' ?><?= fa_num($roi,2) ?>%</td><td><?= h(fmt_date($p['opened_at'])) ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<section class="panel"><div class="panel-title"><div><h2>آخرین تصمیم‌های ربات</h2><p>خریدها و ارزهایی که بررسی شدند اما رد شدند</p></div><span class="tag">دلیل تصمیم ثبت می‌شود</span></div>
<?php if (!$decisions): ?><div class="empty">هنوز تصمیمی ثبت نشده است؛ پس از اجرای کران، نتایج اینجا نمایش داده می‌شوند.</div><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>توکن</th><th>امتیاز</th><th>تصمیم</th><th>دلیل</th><th>زمان</th></tr></thead><tbody>
<?php foreach (array_slice($decisions,0,12) as $d): ?><tr><td><b><?= h($d['symbol'] ?? '—') ?></b><small class="subline"><?= h($d['name'] ?? '') ?></small><small class="subline"><?= h(substr((string)($d['mint'] ?? ''),0,7).'…'.substr((string)($d['mint'] ?? ''),-5)) ?><?php if (!empty($d['dex_url'])): ?> · <a href="<?= h($d['dex_url']) ?>" target="_blank" rel="noopener noreferrer">نمودار</a><?php endif; ?></small></td><td><?= (int)($d['score'] ?? 0) ?>/100</td><td><span class="decision <?= ($d['action'] ?? '')==='BUY'?'buy':'skip' ?>"><?= ($d['action'] ?? '')==='BUY'?'خرید آزمایشی':'عدم ورود' ?></span></td><td class="reason"><?= h($d['reason'] ?? '') ?><?php if (!empty($d['positive_reasons'])): ?><small class="subline"><?= h(implode(' | ', $d['positive_reasons'])) ?></small><?php endif; ?><?php if (!empty($d['blocks'])): ?><small class="subline negative"><?= h(implode(' | ', $d['blocks'])) ?></small><?php endif; ?></td><td><?= h(fmt_date($d['at'] ?? '')) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<div class="grid two-col">
<section class="panel"><div class="panel-title"><div><h2>گزارش روزانه</h2><p>ارزش حساب در پایان آخرین اجرای هر روز</p></div></div>
<?php if (!$daily): ?><div class="empty">گزارش روزانه پس از اولین اجرای کران ایجاد می‌شود.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>روز</th><th>ارزش حساب</th><th>ارزش تومانی</th><th>وجه نقد</th><th>موقعیت باز</th><th>سود/زیان بسته‌شده</th></tr></thead><tbody><?php foreach (array_slice(array_reverse($daily),0,7) as $d): ?><tr><td><?= h($d['date']) ?></td><td>$<?= fa_num($d['equity_usdt'],4) ?></td><td><?= !empty($d['equity_toman']) ? fa_num($d['equity_toman'],0).' تومان' : '—' ?></td><td>$<?= fa_num($d['cash_usdt'],4) ?></td><td><?= (int)$d['open_positions'] ?></td><td class="<?= (float)$d['realized_pnl_usdt']>=0?'positive':'negative' ?>">$<?= fa_num($d['realized_pnl_usdt'],4) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<section class="panel"><div class="panel-title"><div><h2>آخرین معاملات</h2><p>سوابق ورود و خروج، هزینه و علت</p></div><a class="text-link" href="export.php">خروجی CSV</a></div>
<?php if (!$trades): ?><div class="empty">هنوز معامله‌ای انجام نشده است.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>نوع</th><th>توکن</th><th>مبلغ</th><th>سود/زیان</th><th>علت</th><th>زمان</th></tr></thead><tbody><?php foreach (array_slice($trades,0,8) as $t): ?><tr><td><span class="decision <?= $t['type']==='BUY'?'buy':(($t['type']==='CONVERT')?'convert':'sell') ?>"><?= $t['type']==='BUY'?'خرید':(($t['type']==='CONVERT')?'تبدیل':'فروش') ?></span></td><td><?= h($t['symbol']) ?></td><td><?= $t['type']==='CONVERT' ? fa_num($t['amount_toman'] ?? 0,0).' تومان → $'.fa_num($t['amount_usdt'] ?? 0,4) : '$'.fa_num($t['amount_usdt'] ?? 0,3) ?></td><td class="<?= (float)($t['pnl_usdt'] ?? 0)>=0?'positive':'negative' ?>"><?= isset($t['pnl_usdt']) ? '$'.fa_num($t['pnl_usdt'],4) : '—' ?></td><td class="reason"><?= h($t['reason'] ?? '') ?><?php $tradeReasons = $t['signal_reasons'] ?? ($t['entry_reasons'] ?? []); if (!empty($tradeReasons)): ?><small class="subline"><?= h(implode(' | ', $tradeReasons)) ?></small><?php endif; ?></td><td><?= h(fmt_date($t['at'])) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
</div>
<div class="footer-note">این سامانه فقط Paper Trading انجام می‌دهد. هیچ کیف پول، کلید خصوصی یا تراکنش واقعی در آن وجود ندارد. سود و زیان شبیه‌سازی‌شده، تضمین‌کننده نتیجه معاملات واقعی نیست.</div>
</main></div></body></html>
