<?php
require_once __DIR__ . '/app/common.php';
app_session_start();
$_SESSION=[]; session_destroy();
header('Location: login.php'); exit;
